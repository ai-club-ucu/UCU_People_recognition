from distutils.core import setup
setup(name="Trapezna_Motion_Heatmap",
      version="1.0.0",
      description="A project for Trapezna for building heatmap based on"
                  "people`s Motion",
      url="https://github.com/andrwkoval/trapezna",
      author='Yura Yelisjejev, Andrii Koval',
      packages=["modules"])